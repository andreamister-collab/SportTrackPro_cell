#!/usr/bin/env node
// ============================================================
// SportTrackPro — Crea primo utente Admin in Turso
// 
// Install dipendenze: npm install @libsql/client bcryptjs dotenv
// Uso:   node create_admin.js
// ============================================================

import { createClient } from '@libsql/client';
import bcrypt from 'bcryptjs';
import readline from 'readline';

// ── Carica .env se presente ───────────────────────────────────
try {
    const { config } = await import('dotenv');
    config();
} catch {}

// ── Turso connection ──────────────────────────────────────────
const TURSO_URL   = process.env.TURSO_DATABASE_URL;
const TURSO_TOKEN = process.env.TURSO_AUTH_TOKEN;

if (!TURSO_URL || !TURSO_TOKEN) {
    console.error('\n❌ Mancano le variabili d\'ambiente TURSO_DATABASE_URL e TURSO_AUTH_TOKEN');
    console.error('   Crea un file .env con:');
    console.error('   TURSO_DATABASE_URL=libsql://tuo-db.turso.io');
    console.error('   TURSO_AUTH_TOKEN=eyJ...\n');
    process.exit(1);
}

const db = createClient({ url: TURSO_URL, authToken: TURSO_TOKEN });

// ── UUID generator ────────────────────────────────────────────
const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
});

// ── Input helpers ─────────────────────────────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

const ask = (question, defaultVal = '') => new Promise(resolve => {
    const hint = defaultVal ? ` [${defaultVal}]` : '';
    rl.question(`${question}${hint}: `, answer => {
        resolve(answer.trim() || defaultVal);
    });
});

const askHidden = (question) => new Promise(resolve => {
    // Nasconde l'input della password
    process.stdout.write(question + ': ');
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    let password = '';
    process.stdin.on('data', function handler(char) {
        char = char.toString();
        if (char === '\n' || char === '\r' || char === '\u0004') {
            process.stdin.setRawMode(false);
            process.stdin.pause();
            process.stdin.removeListener('data', handler);
            process.stdout.write('\n');
            resolve(password);
        } else if (char === '\u0003') {
            process.stdout.write('\n');
            process.exit(0);
        } else if (char === '\u007f' || char === '\b') {
            if (password.length > 0) {
                password = password.slice(0, -1);
                process.stdout.write('\b \b');
            }
        } else {
            password += char;
            process.stdout.write('*');
        }
    });
});

// ── Main ──────────────────────────────────────────────────────
console.log('\n╔══════════════════════════════════════════════╗');
console.log('║   SportTrackPro — Creazione Utente Admin    ║');
console.log('╚══════════════════════════════════════════════╝\n');

try {
    // Test connessione
    await db.execute('SELECT 1');
    console.log('✅ Connessione a Turso riuscita\n');
} catch (e) {
    console.error('❌ Impossibile connettersi a Turso:', e.message);
    process.exit(1);
}

// Controlla se esiste già un admin
const existing = await db.execute("SELECT id, username, name FROM users WHERE role = 'admin' LIMIT 5");
if (existing.rows.length > 0) {
    console.log('⚠️  Esistono già questi utenti admin:\n');
    existing.rows.forEach(r => console.log(`   • ${r.username}  (${r.name || 'senza nome'})`));
    console.log('');
    const proceed = await ask('Vuoi creare un altro admin? (s/N)', 'N');
    if (proceed.toLowerCase() !== 's') {
        console.log('\nOperazione annullata.\n');
        rl.close();
        process.exit(0);
    }
    console.log('');
}

// Raccolta dati
console.log('Inserisci i dati per il nuovo admin:\n');

const username = await ask('Username', 'admin');
const name     = await ask('Nome completo', 'Amministratore');
const email    = await ask('Email', '');

let password = '';
let confirm  = '';
let attempts = 0;

while (true) {
    if (attempts >= 3) {
        console.error('\n❌ Troppi tentativi. Operazione annullata.\n');
        rl.close();
        process.exit(1);
    }
    password = await askHidden('Password (min. 8 caratteri)');
    if (password.length < 8) {
        console.log('⚠️  La password deve avere almeno 8 caratteri.\n');
        attempts++;
        continue;
    }
    confirm = await askHidden('Conferma password');
    if (password !== confirm) {
        console.log('⚠️  Le password non coincidono. Riprova.\n');
        attempts++;
        continue;
    }
    break;
}

rl.close();

// Verifica username non duplicato
const dup = await db.execute({
    sql:  'SELECT id FROM users WHERE username = :u LIMIT 1',
    args: { u: username },
});
if (dup.rows.length > 0) {
    console.error(`\n❌ Username "${username}" già in uso. Scegli un altro username.\n`);
    process.exit(1);
}

// Hash password
console.log('\n⏳ Generazione hash password...');
const hash = await bcrypt.hash(password, 12); // 12 rounds = più sicuro

// Inserisci in Turso
const id = uuid();
await db.execute({
    sql: `INSERT INTO users (id, username, name, email, password_hash, role, society_id)
          VALUES (:id, :username, :name, :email, :hash, 'admin', NULL)`,
    args: { id, username, name, email: email || null, hash },
});

// Verifica
const check = await db.execute({
    sql:  'SELECT id, username, name, role FROM users WHERE id = :id',
    args: { id },
});

if (check.rows.length > 0) {
    console.log('\n╔══════════════════════════════════════════════╗');
    console.log('║          ✅ Admin creato con successo!       ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log(`║  Username : ${username.padEnd(32)}║`);
    console.log(`║  Nome     : ${name.padEnd(32)}║`);
    console.log(`║  Ruolo    : admin${''.padEnd(27)}║`);
    console.log(`║  ID       : ${id.slice(0,32)}║`);
    console.log('╚══════════════════════════════════════════════╝');
    console.log('\n💡 Puoi ora fare login nell\'app con queste credenziali.');
    console.log('   Ricordati di cambiare la password dopo il primo accesso!\n');
} else {
    console.error('\n❌ Inserimento fallito. Controlla i log.\n');
    process.exit(1);
}
